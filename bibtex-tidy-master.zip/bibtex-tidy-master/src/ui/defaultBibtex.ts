export const DEFAULT_BIBTEX = `Click Tidy to clean up the entries below      
@Book{sweig42,
  Author =	 { Stefa{n} Sweig },
  title =	 { The impossible book },
  publisher =	 { Dead Poet Society},
  year =	 1942,
  month =        mar
}
@article{steward03,
  author =	 {Martha Steward},
  title =	 {Cooking behind bars}, publisher = "Culinary Expert Series",
  year = {2003}
}
@Book{impossible,
  Author =	 { Stefan Sweig },
  title =	 { The impossible book },
  publisher =	 { Dead Poet Society},
  year =	 1942,
  month =        mar
}
`;
