import 'core-js/modules/es.array.flat-map';
import 'core-js/modules/es.object.from-entries';
import 'core-js/modules/es.string.trim-end';
import 'core-js/modules/web.url-search-params';
import App from './App.svelte';

new App({ target: document.body });
