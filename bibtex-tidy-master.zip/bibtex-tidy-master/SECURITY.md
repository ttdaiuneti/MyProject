# Security Policy

## Reporting a Vulnerability

If you have found a security vulnerability (either in bibtex-tidy or its dependencies) then email peter@peter-west.uk.

For bugs and minor vulnerabilities, please open an issue here: https://github.com/FlamingTempura/bibtex-tidy/issues/new.
